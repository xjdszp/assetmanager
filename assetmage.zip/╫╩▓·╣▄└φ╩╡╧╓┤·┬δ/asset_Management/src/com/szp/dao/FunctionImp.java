package com.szp.dao;

import java.util.ArrayList;
import java.util.List;

import com.szp.bean.Assets;
import com.szp.bean.Storehouse;

public class FunctionImp implements Functions{

	@Override
	public boolean add(Assets asset) throws Exception {
		boolean f=false;
		if(asset!=null) {
		  f=Storehouse.getListAsset().add(asset);
		}
		return f;
	}

	@Override
	public Assets distribut(String office, String type,String size,String color) throws Exception {
		int j=0;
		List<Assets> listAsset=Storehouse.getListAsset();
		Assets a=null;
		if(type.equals("table")) {
		    for(int i=0;i<listAsset.size();i++) {
		    	if(listAsset.get(i).getStatus()==1&&listAsset.get(i).getType().equals(type)&&listAsset.get(i).getSize().equals(size)&&listAsset.get(i).getColor().equals(color)&&listAsset.get(i).getBadStatus()==1) {
		    		a=listAsset.get(i);
		    		j=i;
		    		break;
		    	}
		    }
		}else if(type.equals("chair")){
			 for(int i=0;i<listAsset.size();i++) {
			    	if(listAsset.get(i).getStatus()==1&&listAsset.get(i).getType().equals(type)) {
			    		a=listAsset.get(i);
			    	}
			 }
		}
	    if(a!=null) {
	    	a.setOffice(office);
	    	a.setStatus(2);
	    }
		return a;
	}

	@Override
	public List<Assets> getBadAsset() throws Exception {
		List<Assets> list=new ArrayList<>();
		for(Assets a:Storehouse.getListAsset()) {
			if(a.getBadStatus()==0) {
				list.add(a);
			}
		}
		return list;
	}

	@Override
	public Assets maintain(Assets asset) throws Exception {
		List<Assets> list=Storehouse.getListAsset();
		Assets as=null;
		Assets as1=null;
		int j=0;
		int k=0;
		if(asset!=null) {
			if(asset.getType().equals("table")) {
				for(Assets a:list) {
					if(a.getColor().equals(asset.getColor())&&a.getSize().equals(asset.getSize())&&a.getPrice()==asset.getPrice()&&a.getType().equals(asset.getType())&&a.getStatus()==0&&a.getBadStatus()==1) {
						as=a;
						break;
					}
				}
			}else {
				for(Assets a:list) {
					if(a.getPrice()==asset.getPrice()&&a.getType().equals(asset.getType())&&a.getStatus()==0&&a.getBadStatus()==1) {
						as=a;
						break;
					}
				}
			}
			for(Assets a:list) {
				if(a.getId().equals(asset.getId())) {
					as1=a;
					break;
				}
			}
		}
		as1.setBadStatus(2);
		as1.setStatus(2);
		as.setStatus(1);
		as.setOffice(asset.getOffice());
		as1.setOffice(null);
		return as;
	}

	@Override
	public List<Assets> getAll() throws Exception {	
		return Storehouse.getListAsset() ;
	}

}
