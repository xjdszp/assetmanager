package com.szp.dao;

import java.util.List;

import com.szp.bean.Assets;

public interface Functions{
	//查看所有物品
	public List<Assets> getAll()throws Exception ;
	//项仓库中增加物品,返回物品的资产编号，便于查询
	public boolean add(Assets asset) throws Exception ;
	//分配物品返回物品的资产编号，便于查询分配的结果
	public Assets distribut(String office,String type,String size,String color)throws Exception;
	//查询需要维修的物品
	public List<Assets> getBadAsset()throws Exception;
	//资产维修
	public Assets maintain(Assets asset) throws Exception;
}
