package com.szp.bean;

import java.util.ArrayList;
import java.util.List;

public class Storehouse {
	private static List<Assets> listAsset=new ArrayList<Assets>();

	public static List<Assets> getListAsset() {
		return listAsset;
	}

	public static void setListAsset(List<Assets> listTable) {
		Storehouse.listAsset = listAsset;
	}
	
}
