package com.szp.bean;

import java.util.List;

public class Assets {
	private String id;
	private String color;
	private String size;
	private double price; 
	private String supplier;
	private String type;
	private int status;
	private int badStatus;
	private String office;
	public Assets() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Assets(String id, String color, String size, double price, String supplier, String type, int status,
			int badStatus, String office) {
		super();
		this.id = id;
		this.color = color;
		this.size = size;
		this.price = price;
		this.supplier = supplier;
		this.type = type;
		this.status = status;
		this.badStatus = badStatus;
		this.office = office;
	}



	public int getBadStatus() {
		return badStatus;
	}



	public void setBadStatus(int badStatus) {
		this.badStatus = badStatus;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	@Override
	public String toString() {
		String str=null;
		String s1=null;
		String s2=null;
		if(this.badStatus==0) {
			s1="损坏";
		}else if(this.badStatus==1){
			s1="完好";
		}else if(this.badStatus==2) {
			s1="维修中";
		}
		if(this.status==0) {
			s2="未分配";
		}else if(this.status==1){
			s2="已分配";
		}else {
			s2="已回收";
		}
		str=this.id+"\t"+this.color+"\t"+
				this.price+"\t"+this.size+"\t"+s2+"("+
				this.status+")\t"+this.type+"\t"
				+this.supplier+"\t"+this.office+"\t"+s1+"("+this.badStatus+")";
		return str;
	}
	
}
 