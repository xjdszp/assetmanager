package com.szp.util;

import java.util.UUID;

public class Getuuid {
	//用来生成资产编号
	public static String getUuid(){
		String s=UUID.randomUUID().toString().replace("-", "");
		return s;
	}
}
