package com.szp.test;
import java.util.List;
import java.util.Scanner;

import com.sun.xml.internal.ws.policy.AssertionSet;
import com.szp.bean.Assets;
import com.szp.bean.Storehouse;
import com.szp.dao.FunctionImp;
import com.szp.dao.Functions;
import com.szp.util.Getuuid;

public class test {

	public static void main(String[] args) throws Exception {
		test t =new test();
	    for(int i=0;i<20;i++) {
			Assets a =new Assets();
			if(i<5) {
				a.setColor("black");
				a.setStatus(0);
				a.setBadStatus(1);
			}else if(i<10&&i>=5) {
				a.setOffice("A");
				a.setStatus(1);
				a.setColor("white");
				a.setBadStatus(1);
			}else if(i<15&&i>=10) {
				a.setOffice("B");
				a.setStatus(1);
				a.setColor("black");
				a.setBadStatus(0);
			}else {
				a.setStatus(0);
				a.setColor("white");
				a.setBadStatus(1);
			}
			a.setSize("160cm");
			a.setPrice(240);
			a.setId(Getuuid.getUuid());
			a.setType("table");
			a.setSupplier("甲");
			Storehouse.getListAsset().add(a);	
		}
	    for(int i=0;i<20;i++) {
	    	Assets a=new Assets();
	    	if(i<5) {
	    		a.setBadStatus(0);
	    		a.setStatus(1);
	    		a.setOffice("B");
	    		a.setPrice(100);
	    	}
	    	if(i>=5&&i<10) {
	    		a.setBadStatus(1);
	    		a.setStatus(0);
	    		a.setOffice(null);
	    		a.setPrice(100);
	    	}
	    	if(i>=10&&i<15) {
	    		a.setBadStatus(1);
	    		a.setStatus(0);
	    		a.setOffice(null);
	    		a.setPrice(150);
	    	}
	    	if(i>=15&&i<20) {
	    		a.setOffice("A");
	    		a.setBadStatus(1);
	    		a.setStatus(1);
	    		a.setPrice(100);
	    	}
	    	a.setId(Getuuid.getUuid());
			a.setType("chair");
			a.setSupplier("甲");
			Storehouse.getListAsset().add(a);
	    }
		Functions f=new FunctionImp();
		System.out.println("1:查看所有物品");
		System.out.println("2:添加物品");
		System.out.println("3:分配物品");
		System.out.println("4:查询需要维修物品");
		System.out.println("5:维修商品");
		System.out.println("6:退出系统");
		Scanner scan=new Scanner(System.in);
		int num=0;
		while(true) {
			num=scan.nextInt();
			if(num==1) {
				System.out.println("资产编码"+"\t\t\t\t"+"颜色"+"\t"+"价格(元)"+"\t"+"尺寸"+"\t"+"分配状态"+"\t"+"类型"+"\t"+"厂商"+"\t"+"办公室"+"\t"+"完好程度");
				System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
				for(Assets a:Storehouse.getListAsset()) {
					System.out.println(a.toString());
				}
			}else if(num==2) {
				boolean flag=false;
				Assets a=t.newProduct();
				if(a!=null) {
				 flag=f.add(a);
				}
				if(flag) {
					System.out.println("添加成功");
				}else {
					System.out.println("添加失败");
				}
			}else if(num==3) {
				String str=null;
				String type=null;
				String office=null;
				String size=null;
				String color=null;
				System.out.println("请输入要分配的物品：table or chair");
				while(true) {
					str=scan.next();
					if(str.equals("table")||str.equals("chair")) {
						type=str;
						break;
					}else {
						System.out.println("输入格式有误，重新输入物品");
					}
				}
				if(type.equals("table")) {
					while(true) {
						System.out.println("请输入要分配的尺寸：120cm or 160cm");
						str=scan.next();
						if(str.equals("120cm")||str.equals("160cm")) {
							size=str;
							break;
						}else {
							System.out.println("输入格式有误，重新输入尺寸");
						}
					}
					while(true) {
						System.out.println("请输入要分配的颜色：white or black");
						str=scan.next();
						if(str.equals("white")||str.equals("black")) {
							color=str;
							break;
						}else {
							System.out.println("输入格式有误，重新输入颜色");
						}
					}
				}
				while(true) {
					System.out.println("请输入要分配的办公室：A B C D E");
					str=scan.next();
					if(str.equals("A")||str.equals("B")||str.equals("C")||str.equals("D")||str.equals("E")) {
						office=str;
						break;
					}else {
						System.out.println("输入格式有误，重新输入office");
					}
				}
				
				Assets as=null;
				as=f.distribut(office, type, size, color);	
				if(as!=null) {
					System.out.println("分配成功结果如下");
					System.out.println("资产编码"+"\t\t\t\t"+"颜色"+"\t"+"价格(元)"+"\t"+"尺寸"+"\t"+"分配状态"+"\t"+"类型"+"\t"+"厂商"+"\t"+"办公室"+"\t"+"完好程度");
					System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println(as.toString());
				}else {
					System.out.println("没有可以分配的物品了");
				}
			}else if(num==4) {
				 List<Assets> list=f.getBadAsset();
				 t.printBad(list);
			}else if(num==5) {
		        System.out.println("需要维修的物品如下,如果需要维修，请输入需要维修产品的资产编号：");		
				List<Assets> list=f.getBadAsset();
				t.printBad(list);
				Assets as=null;
				String s=null;
				
				List<Assets> list1=Storehouse.getListAsset();
			
				while(true) {
					System.out.println("请输入需要维修产品的资产编号");
					s=scan.next();
					for(Assets a:list1) {
						if(a.getId().equals(s)) {
							as=a;
							break;
						}else {
							
						}
					}
					if(as!=null) {
						break;
					}else {
						System.out.println("您输入的资产号不对，请重新输入");
					}
				}
				Assets asset=f.maintain(as);
				if(asset!=null) {
					System.out.println("损坏替换后的物品为");
					System.out.println("资产编码"+"\t\t\t\t"+"颜色"+"\t"+"价格(元)"+"\t"+"尺寸"+"\t"+"分配状态"+"\t"+"类型"+"\t"+"厂商"+"\t"+"办公室"+"\t"+"完好程度");
					System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println(asset.toString());
				}else {
					System.out.println("没有同类型的产品可以替换");
				}
				
			}
			if(num==6) {
				System.out.println("退出系统");
				break;
			}
		}
	}
	
	//查询已经损坏的商品
	 void printBad(List<Assets> list ) {
			if(list.size()!=0) {
				System.out.println("需要维修的物品如下");
				System.out.println("资产编码"+"\t\t\t\t"+"颜色"+"\t"+"价格(元)"+"\t"+"尺寸"+"\t"+"分配状态"+"\t"+"类型"+"\t"+"厂商"+"\t"+"办公室"+"\t"+"完好程度");
				System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
				for(Assets a:list) {
					System.out.println(a.toString());
				}
			}else {
				System.out.println("所有物品完好，没有需要修复的物品");
			}
	 }
	
	//新建一个物品
	  Assets newProduct() {
		Scanner scan=new Scanner(System.in);
		String s=null;
		Assets a=new Assets();
		String type=null;
		while(true) {
			System.out.println("输入添加物品的类型：table or chair");
			s=scan.next();
			if(s.equals("table")||s.equals("chair")) {
				type=s;
				break;
			}else {
				System.out.println("输入格式错误，重新输入");
			}
		}
		if(type.equals("table")) {
			System.out.println("请输入颜色：white or black");
			while(true) {
				 s=scan.next();
				if(s.equals("white")||s.equals("black")) {
					a.setColor(s);
					break;
				}else {
					System.out.println("输入有误，重新输入");
				}
			}
			System.out.println("请输入价格：");
			float price=scan.nextFloat();
			a.setPrice(price);
			System.out.println("请输入尺寸：120cm or 160cm");
			while(true) {
				s=scan.next();
				if(s.equals("120cm")||s.equals("160cm")) {
					a.setSize(s);;
					break;
				}else {
					System.out.println("输入有误，重新输入尺寸");
				}
			}
		}else {
			System.out.println("请输入价格：");
			float price=scan.nextFloat();
			a.setPrice(price);
		}
	
		a.setStatus(0);
		a.setSupplier("甲");
		a.setId(Getuuid.getUuid());
		a.setType(type);
		a.setBadStatus(1);
		return a;		
	}
}
