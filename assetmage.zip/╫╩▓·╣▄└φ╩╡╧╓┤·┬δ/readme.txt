1.将该工程导入
2.编译后直接运行com.szp.test中的test类的main方法，将会展示所有的功能